list.Set( "Doctor_Wilson", "models/bunny/house_wilson/house_doctor_wilson.mdl" )   // "models/bunny/house_wilson/house_doctor_wilson.mdl" )
player_manager.AddValidModel( "Doctor_Wilson", "models/bunny/house_wilson/house_doctor_wilson.mdl" )   // "models/bunny/house_wilson/house_doctor_wilson.mdl" )
player_manager.AddValidHands( "Doctor_Wilson", "models/bunny/house_wilson/house_doctor_wilson_hands.mdl", 0, "00000000" ) // "models/bunny/house_wilson/house_doctor_wilson_hands.mdl", 0, "00000000"




